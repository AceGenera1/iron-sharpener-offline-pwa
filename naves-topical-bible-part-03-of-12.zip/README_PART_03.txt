Nave's Topical Bible import part 3 of 12. Upload all 12 part ZIPs to the GitHub repo root, then run the Import Nave Small ZIP Parts workflow. Contains 444 JSON files.
